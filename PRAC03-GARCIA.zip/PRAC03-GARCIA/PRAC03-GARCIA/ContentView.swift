import SwiftUI
import SwiftData

struct ContentView: View {
    @Environment(\.modelContext) private var contextoModelo
    @Query(sort: \Profesor.apellido) private var profesores: [Profesor]
    @State private var textoBusqueda = ""
    @State private var mostrarFormulario = false
    
    var profesoresFiltrados: [Profesor] {
        if textoBusqueda.isEmpty {
            return profesores
        } else {
            return profesores.filter { profesor in
                profesor.nombre.localizedCaseInsensitiveContains(textoBusqueda) ||
                profesor.apellido.localizedCaseInsensitiveContains(textoBusqueda)
            }
        }
    }

    var body: some View {
        NavigationStack {
            List {
                ForEach(profesoresFiltrados) { profesor in
                    VStack(alignment: .leading, spacing: 4) {
                        Text("\(profesor.nombre) \(profesor.apellido)")
                            .font(.headline)
                        Text(profesor.cargo)
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                }
                .onDelete(perform: eliminarProfesores)
            }
            .navigationTitle("Teachers")
            .searchable(text: $textoBusqueda, prompt: "Search teachers...")
            .toolbar {
        
                ToolbarItem(placement: .navigationBarLeading) {
                    EditButton()
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: { mostrarFormulario = true }) {
                        Image(systemName: "plus")
                    }
                }
            }
            .sheet(isPresented: $mostrarFormulario) {
                VistaAgregarProfesor()
            }
            .overlay {
                if profesoresFiltrados.isEmpty {
                    ContentUnavailableView(
                        "No hay profesores",
                        systemImage: "person.slash",
                        description: Text("Presiona el botón + para añadir un nuevo profesor.")
                    )
                }
            }
        }
    }
    
    private func eliminarProfesores(en offsets: IndexSet) {
        withAnimation {
            for indice in offsets {
                contextoModelo.delete(profesoresFiltrados[indice])
            }
        }
    }
}

#Preview {
    ContentView()
        .modelContainer(for: Profesor.self)
}
