//
//  Profesor.swift
//  PRAC03-GARCIA
//
//  Created by Tecsup on 1/06/26.
//

import Foundation
import SwiftData
@Model
final class Profesor {
    var nombre: String
    var apellido: String
    var correo: String
    var telefono: String
    var fechaNacimiento: Date
    var cargo: String
    var fechaContratacion: Date
    var estaActivo: Bool
    // tecsup en ves de apellido
    
    init(
        nombre: String = "",
        apellido: String = "Tecsup",
        correo: String = "",
        telefono: String = "",
        fechaNacimiento: Date = Date(),
        cargo: String = "",
        fechaContratacion: Date = Date(),
        estaActivo: Bool = true
    ) {
        self.nombre = nombre
        self.apellido = apellido
        self.correo = correo
        self.telefono = telefono
        self.fechaNacimiento = fechaNacimiento
        self.cargo = cargo
        self.fechaContratacion = fechaContratacion
        self.estaActivo = estaActivo
    }
}
