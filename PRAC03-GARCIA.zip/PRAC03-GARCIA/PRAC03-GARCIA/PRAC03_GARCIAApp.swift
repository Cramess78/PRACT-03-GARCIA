//
//  PRAC03_GARCIAApp.swift
//  PRAC03-GARCIA
//
//  Created by Tecsup on 1/06/26.
//

import SwiftUI
import SwiftData

@main
struct PRAC03_GARCIAApp: App {
    var sharedModelContainer: ModelContainer = {
        let schema = Schema([
            Profesor.self,
        ])
        let modelConfiguration = ModelConfiguration(schema: schema, isStoredInMemoryOnly: false)

        do {
            return try ModelContainer(for: schema, configurations: [modelConfiguration])
        } catch {
            fatalError("Could not create ModelContainer: \(error)")
        }
    }()

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .modelContainer(sharedModelContainer)
        .modelContainer(for: Profesor.self)
    }
}
