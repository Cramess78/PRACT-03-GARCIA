//
//  VistaAgregarProfesor.swift
//  PRAC03-GARCIA
//
//  Created by Tecsup on 1/06/26.
//

import Foundation
import SwiftUI
import SwiftData

struct VistaAgregarProfesor: View {
    @Environment(\.modelContext) private var contextoModelo
    @Environment(\.dismiss) private var desestimar
    
    @State private var nombre = ""
    @State private var apellido = "Tecsup"
    @State private var correo = ""
    @State private var telefono = ""
    @State private var fechaNacimiento = Date()
    @State private var cargo = ""
    @State private var fechaContratacion = Date()
    @State private var estaActivo = true
    
    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("PERSONAL INFORMATION")) {
                    TextField("Nombre", text: $nombre)
                    TextField("garcia@tecsup.edu.pe", text: $correo)
                        .keyboardType(.emailAddress)
                        .autocorrectionDisabled()
                        .textInputAutocapitalization(.never)
                    TextField("945784125", text: $telefono)
                        .keyboardType(.phonePad)
                    DatePicker("Fecha de Nacimiento", selection: $fechaNacimiento, displayedComponents: .date)
                }
                
                Section(header: Text("INFORMACION PROFECIONAL")) {
                    TextField("Java Senior", text: $cargo)
                    DatePicker("Hire Date", selection: $fechaContratacion, displayedComponents: .date)
                    Toggle("Active", isOn: $estaActivo)
                }
            }
            .navigationTitle("Add Teacher")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        desestimar()
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") {
                        let nuevoProfesor = Profesor(
                            nombre: nombre,
                            apellido: apellido,
                            correo: correo,
                            telefono: telefono,
                            fechaNacimiento: fechaNacimiento,
                            cargo: cargo,
                            fechaContratacion: fechaContratacion,
                            estaActivo: estaActivo
                        )
                        contextoModelo.insert(nuevoProfesor)
                        desestimar()
                    }
                    .disabled(nombre.isEmpty || apellido.isEmpty)
                }
            }
        }
    }
}
