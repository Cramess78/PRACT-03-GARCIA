//
//  PRAC03_GARCIATests.swift
//  PRAC03-GARCIATests
//
//  Created by Tecsup on 1/06/26.
//

import Testing
@testable import PRAC03_GARCIA

struct PRAC03_GARCIATests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
