//
//  ExamplePublishedView.swift
//  SEM12-GARCIA
//
//  Created by Tecsup on 1/06/26.
//

import Foundation
import SwiftUI
import Combine

// ❌ WITHOUT @Published - UI won't update
class BadCounter: ObservableObject {
    var count = 0  // Missing @Published
}

// ✅ WITH @Published - UI updates automatically
class GoodCounter: ObservableObject {
    @Published var count = 0  // Has @Published
}

struct ExamplePublishedView: View {
    
    @StateObject var badCounter = BadCounter()
    @StateObject var goodCounter = GoodCounter()
    
    var body: some View {
        VStack {
            
            VStack {
                Text("Count: \(badCounter.count)")
                Button("Add") {
                    self.badCounter.count += 1
                }.buttonStyle(.bordered)
            }
            
            Divider()
            
            VStack {
                Text("Count: \(goodCounter.count)")
                Button("Add") {
                    self.goodCounter.count += 1
                }.buttonStyle(.bordered)
            }
            
        }
    }
}
#Preview{
    ExamplePublishedView()
    
}
