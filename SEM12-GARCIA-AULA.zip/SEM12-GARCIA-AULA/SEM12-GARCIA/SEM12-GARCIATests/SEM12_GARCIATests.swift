//
//  SEM12_GARCIATests.swift
//  SEM12-GARCIATests
//
//  Created by Tecsup on 1/06/26.
//

import Testing
@testable import SEM12_GARCIA

struct SEM12_GARCIATests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
