//
//  SEM12_GARCIA_MVVMApp.swift
//  SEM12-GARCIA-MVVM
//
//  Created by Tecsup on 1/06/26.
//

import SwiftUI
import SwiftData
// Created by Juan Leon - Jaime Gómez on 28/05/25.
//

import SwiftUI

@main
struct SEM12_GARCIA_MVVMApp: App {
    @ObservedObject var viewModel = ViewModel()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(viewModel)
        }
    }
}
