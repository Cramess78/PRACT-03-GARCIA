//
//  ViewModel.swift
//  SEM12-GARCIA-MVVM
//
//  Created by Tecsup on 1/06/26.
//

import Foundation
import SwiftUI
import Combine

class ViewModel: ObservableObject {
    @Published var model = Model()
}
