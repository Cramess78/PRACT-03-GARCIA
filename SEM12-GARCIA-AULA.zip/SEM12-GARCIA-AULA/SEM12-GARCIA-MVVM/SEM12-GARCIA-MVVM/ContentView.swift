//
//  ContentView.swift
//  SEM12-GARCIA-MVVM
//
//  Created by Tecsup on 1/06/26.
//
import SwiftUI
struct ContentView: View {
    @EnvironmentObject var viewModel: ViewModel

    var body: some View {
        VStack {
            ContactList()
        }
    }
}

#Preview {
    ContentView()
        .environmentObject(ViewModel())
}
