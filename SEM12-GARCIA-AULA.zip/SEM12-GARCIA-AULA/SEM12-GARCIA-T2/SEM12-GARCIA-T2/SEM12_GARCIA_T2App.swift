//
//  SEM12_GARCIA_T2App.swift
//  SEM12-GARCIA-T2
//
//  Created by Tecsup on 1/06/26.
//

import SwiftUI
import SwiftData

@main
struct SEM12_GARCIA_T2App: App {
    var sharedModelContainer: ModelContainer = {
        let schema = Schema([
            Item.self,
        ])
        let modelConfiguration = ModelConfiguration(schema: schema, isStoredInMemoryOnly: false)

        do {
            return try ModelContainer(for: schema, configurations: [modelConfiguration])
        } catch {
            fatalError("Could not create ModelContainer: \(error)")
        }
    }()

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .modelContainer(sharedModelContainer)
    }
}
